local animate = {}


function animate.init()
	a = {}
	a.bits = {}
	for i = 0, 3 do a.bits[i] = false end
	a.count = 0
	a.time_prev = 0
	a.time_now = 0
	a.canvas = love.graphics.newCanvas(32, 16)
	if enable_audio then a.music = love.audio.newSource("data/bach_binary.ogg", "stream") end
end


function animate.start()
	a.time_start = love.timer.getTime()
	if enable_audio then a.music:play() end
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if math.floor(a.time_now * 320 / 60) > math.floor(a.time_prev * 320 / 60) then
		a.count = a.count + 1
		for i = 0, #(a.bits) do
			a.bits[i] = not a.bits[i]
			if a.bits[i] then break end
			if i == #(a.bits) then a.bits[i + 1] = true end
		end
	end
	a.time_prev = a.time_now
	if a.count == 512 then animate.stop() end
end


function animate.draw()
	love.graphics.setCanvas(a.canvas)
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.rectangle("fill", 25, 15, 7, 1)
	for i = 0, 3 do
		if a.bits[i] then
			love.graphics.rectangle("fill", 31 - 2 * i, 8, 1, 7)
		else
			love.graphics.points(31 - 2 * i + 0.5, 13.5)
		end
	end
	for i = 4, #(a.bits) do
		if a.bits[i] then
			love.graphics.rectangle("fill", 36 - 4 * i, 0, 2, 16)
		else
			love.graphics.rectangle("fill", 36 - 4 * i, 10, 2, 2)
			love.graphics.rectangle("fill", 36 - 4 * i, 14, 2, 2)
		end
		if i < #(a.bits) then
			love.graphics.rectangle("fill", 34 - 4 * i, 14, 2, 2)
		end
	end
	love.graphics.setCanvas()
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.draw(a.canvas, 832, 476, 0, 8, 8)
end


function animate.stop()
	playing = false
	a.count = 0
end


function animate.done()
	a = nil
end


return animate