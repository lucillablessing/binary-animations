local animate = {}


function animate.init()
	a = {}
	a.channels = {
		{ s = 1; [16] = 0; [24] = 1; [44] = 0; [60] = 1; [62] = 0; [87] = 1; [89] = 0; };
		{ s = 0; [2] = 2; [16] = 0; [24] = 2; [44] = 0; [60] = 2; [62] = 0; [74] = 4/3; [80] = 0; [87] = 2; [89] = 0; };
		{ s = 0; [4] = 3; [54] = 0; [56] = 3; [62] = 0; [71] = 8/3; [80] = 0; [85] = 3; [89] = 0; };
		{ s = 0; [6] = 4; [16] = 0; [18] = 9/2; [24] = 0; [26] = 4; [46] = 0; [48] = 9/2; [54] = 0; [56] = 15/4; [60] = 4; };
		{ s = 0; [36] = 5; [46] = 0; [48] = 6; [56] = 9/2; [60] = 5; [66] = 0; [68] = 16/3; [83] = 5; };
		{ s = 0; [12] = 6; [32] = 0; [40] = 6; [48] = 0; [50] = 15/2; [56] = 6; [66] = 0; [77] = 20/3; [83] = 6; };
		{ s = 0; [20] = 9; [24] = 0; [28] = 8; [32] = 0; [52] = 9; [56] = 0; [64] = 8; [87] = 0; };
	}
	a.count = 0
	a.time_prev = 0
	a.time_now = 0
	a.anim = 0
	a.canvas = love.graphics.newCanvas(576, 416)
	if enable_audio then a.music = love.audio.newSource("data/byteplex.ogg", "stream") end
end


function animate.start()
	a.time_start = love.timer.getTime()
	if enable_audio then a.music:play() end
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if math.floor(a.time_now * 3 / 4) > math.floor(a.time_prev * 3 / 4) then
		a.count = a.count + 1
		for i = 1, 7 do
			local t = a.channels[i]
			if t[a.count] then t.s = t[a.count] end
		end
		if a.count == 91 then animate.stop() return end
	end
	local t = (a.time_now * 3 / 4) % 1
	if t < 0.0625 then a.anim = t * 16
	elseif t > 0.9375 then a.anim = (1 - t) * 16
	else a.anim = 1
	end
	a.time_prev = a.time_now
end


function animate.draw()
	love.graphics.clear(0, 0, 0, 1)
	if playing then
		love.graphics.setCanvas(a.canvas)
		love.graphics.clear(0, 0, 0, 1)
		if a.count == 90 then love.graphics.setColor(0.5, 0.5, 0.5, 1) end
		for i = 1, 7 do
			love.graphics.rectangle("fill", 0, 448 - 64 * i, 64 * a.anim * a.channels[i].s, 32)
		end
		if a.count == 90 then love.graphics.setColor(1, 1, 1, 1) end
		love.graphics.setCanvas()
		love.graphics.draw(a.canvas, 672, 332)
	end
end


function animate.stop()
	playing = false
	a.count = 0
end


function animate.done()
	a = nil
end


return animate