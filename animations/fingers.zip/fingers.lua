local animate = {}


function animate.init()
	a = {}
	a.fingers = {
		[0] = { ext = false; anim = 0; x0 = 14; y0 = 29; x1 = 4;  y1 = 23; x = 14; y = 29; };
		[1] = { ext = false; anim = 0; x0 = 15; y0 = 29; x1 = 9;  y1 = 8;  x = 15; y = 29; };
		[2] = { ext = false; anim = 0; x0 = 16; y0 = 29; x1 = 18; y1 = 5;  x = 16; y = 29; };
		[3] = { ext = false; anim = 0; x0 = 17; y0 = 29; x1 = 24; y1 = 9;  x = 17; y = 29; };
		[4] = { ext = false; anim = 0; x0 = 18; y0 = 29; x1 = 27; y1 = 20; x = 18; y = 29; };
	}
	a.count = 0
	a.count_str = ""
	a.time_prev = 0
	a.time_now = 0
	a.canvas = love.graphics.newCanvas(32, 32)
	if enable_audio then a.music = love.audio.newSource("data/binary_counter_short.ogg", "stream") end
	love.graphics.setLineWidth(1)
	love.graphics.setLineStyle("rough")
	love.graphics.setNewFont("data/noto_serif.ttf", 72)
end


function animate.start()
	a.time_start = love.timer.getTime()
	a.count_str = "0"
	if enable_audio then a.music:play() end
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if math.floor(a.time_now * 176 / 60) > math.floor(a.time_prev * 176 / 60) then
		for i = 0, 4 do
			local f = a.fingers[i]
			f.ext = not f.ext
			if f.ext then break end
		end
		a.count = a.count + 1
		a.count_str = tostring(a.count)
	end
	if math.floor(a.time_now * 60) > math.floor(a.time_prev * 60) then
		for i = 0, 4 do
			local f = a.fingers[i]
			if f.ext and f.anim < 1 then
				f.anim = math.min(1, f.anim + 0.25)
				f.x = (1 - f.anim) * f.x0 + f.anim * f.x1
				f.y = (1 - f.anim) * f.y0 + f.anim * f.y1
			end
			if not f.ext and f.anim > 0 then
				f.anim = math.max(0, f.anim - 0.25)
				f.x = (1 - f.anim) * f.x0 + f.anim * f.x1
				f.y = (1 - f.anim) * f.y0 + f.anim * f.y1
			end
		end
	end
	a.time_prev = a.time_now
	if a.count == 32 then animate.stop() end
end


function animate.draw()
	love.graphics.setCanvas(a.canvas)
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.line(14, 29, 18, 29)
	for i = 0, 4 do
		local f = a.fingers[i]
		love.graphics.line(f.x0, f.y0, f.x, f.y)
	end
	love.graphics.setCanvas()
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.draw(a.canvas, 448, 0, 0, 32, 32)
	love.graphics.printf(a.count_str, 0, 960, 1920, "center")
end


function animate.stop()
	playing = false
	a.count = 0
	a.count_str = ""
	for i = 0, 4 do
		local f = a.fingers[i]
		f.x = f.x0
		f.y = f.y0
	end
end


function animate.done()
	a = nil
end


return animate