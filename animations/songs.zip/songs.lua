local animate = {}


function animate.init()
	a = {}
	a.song_images = {}
	for i = 0, 7 do a.song_images[i] = love.graphics.newImage("data/" .. i .. ".png") end
	a.bits = {}
	for i = 0, 2 do a.bits[i] = { ext = false; anim = 0; height = 176; } end
	a.anim = 0
	a.count = 0
	a.time_prev = 0
	a.time_now = 0
	a.canvas = love.graphics.newCanvas(1024, 384)
end


function animate.start()
	a.time_start = love.timer.getTime()
end


function animate.advance()
	a.count = a.count + 1
	for i = 0, 2 do
		local b = a.bits[i]
		b.ext = not b.ext
		if b.ext then break end
	end
	a.anim = 1
	a.time_start = love.timer.getTime()
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if a.anim > 0 then
		if math.floor(a.time_now * 60) > math.floor(a.time_prev * 60) then
			a.anim = math.max(0, 1 - a.time_now)
			for i = 0, 2 do
				local b = a.bits[i]
				if b.ext and b.anim < 1 then
					b.anim = 1 - a.anim
					b.height = (1 - b.anim) * 176
				end
				if not b.ext and b.anim > 0 then
					b.anim = a.anim
					b.height = (1 - b.anim) * 176
				end
			end
		end
	end
	a.time_prev = a.time_now
end


function animate.draw()
	love.graphics.setCanvas(a.canvas)
	love.graphics.clear(0, 0, 0, 1)
	if a.anim > 0 then love.graphics.setColor(1, 1, 1, 1) end
	for i = 0, 2 do
		local b = a.bits[i]
		love.graphics.rectangle("fill", 264 - i * 96, b.height, 32, 192 - b.height)
	end
	if a.anim > 0 then
		love.graphics.setColor(1, 1, 1, a.anim)
		local t = a.song_images[a.count - 1]
		if t then love.graphics.draw(t, 64, 256) end
		love.graphics.setColor(1, 1, 1, 1 - a.anim)
		local t = a.song_images[a.count]
		if t then love.graphics.draw(t, 64, 256) end
	else
		local t = a.song_images[a.count]
		if t then love.graphics.draw(t, 64, 256) end
	end
	if a.anim > 0 then love.graphics.setColor(1, 1, 1, 1) end
	love.graphics.setCanvas()
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.draw(a.canvas, 0, 696)
end


function animate.stop()
	playing = false
	a.count = 0
end


function animate.done()
	a = nil
end


return animate