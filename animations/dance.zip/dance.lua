local animate = {}


function animate.init()
	a = {}
	a.binary_names = {}
	a.quaternary_names = {}
	do
		local i, j = 0, 0
		for l in love.filesystem.lines("data/binary_names.txt") do
			a.binary_names[i] = l
			i = i + 1
		end
		for l in love.filesystem.lines("data/quaternary_names.txt") do
			a.quaternary_names[j] = l
			j = j + 1
		end
	end
	a.frame = 0
	a.count = 0
	a.time_prev = 0
	a.time_now = 0
	if enable_audio then a.music = love.audio.newSource("data/dance_of_the_symbols_short.ogg", "stream") end
	love.graphics.setNewFont("data/noto_mono.ttf", 36)
end


function animate.start()
	a.time_start = love.timer.getTime()
	if enable_audio then a.music:play() end
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if math.floor(a.time_now * 6) > math.floor(a.time_prev * 6) then
		a.frame = a.frame + 1
		if a.frame % 3 == 0 or a.count >= 64 then a.count = a.count + 1 end
	end
	a.time_prev = a.time_now
	if a.count == 256 then animate.stop() end
end


function animate.draw()
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.setColor(0.1, 0.1, 0.1, 1)
	love.graphics.rectangle("fill", 0, 48, 1920, 48)
	love.graphics.rectangle("fill", 0, 480, 1920, 48)
	love.graphics.setColor(0.6, 0.6, 0.6, 1)
	love.graphics.printf("Number", 64, 52, 256, "center")
	love.graphics.printf("Full binary name", 1216, 52, 640, "center")
	love.graphics.printf("Quaternary name", 448, 52, 640, "center")
	love.graphics.setColor(1, 1, 1, 1)
	love.graphics.printf(tostring(a.count), 64, 484, 256, "right")
	love.graphics.setColor(0.8, 0.8, 0.8, 1)
	love.graphics.printf(a.binary_names[a.count], 1216, 484, 640, "right")
	love.graphics.printf(a.quaternary_names[a.count], 448, 484, 640, "right")
	love.graphics.setColor(0.4, 0.4, 0.4, 1)
	for i = a.count - 1, math.max(0, a.count - 8), -1 do
		love.graphics.printf(tostring(i), 64, 484 + 48 * (i - a.count), 256, "right")
		love.graphics.printf(a.binary_names[i], 1216, 484 + 48 * (i - a.count), 640, "right")
		love.graphics.printf(a.quaternary_names[i], 448, 484 + 48 * (i - a.count), 640, "right")
	end
	for i = a.count + 1, math.min(256, a.count + 8), 1 do
		love.graphics.printf(tostring(i), 64, 484 + 48 * (i - a.count), 256, "right")
		love.graphics.printf(a.binary_names[i], 1216, 484 + 48 * (i - a.count), 640, "right")
		love.graphics.printf(a.quaternary_names[i], 448, 484 + 48 * (i - a.count), 640, "right")
	end
end


function animate.stop()
	playing = false
end


function animate.done()
	a = nil
end


return animate