local animate = {}


function animate.init()
	a = {}
	a.fractions = {
		[32] = "3"; [33] = "2"; [34] = "13"; [36] = "1111";
		[40] = "1"; [41] = "050505"; [47] = "043"; [50] = "04"; [52] = "0333";
		[62] = "0313452421"; [72] = "0313452421"; [82] = "0313452421";
		[96] = "3"; [97] = "2"; [98] = "13"; [100] = "1111";
		[104] = "1"; [105] = "050505"; [111] = "043"; [114] = "04"; [116] = "0333";
		[128] = "0313452421"; [138] = "0313452421";
		[149] = "0204122453514331"; [165] = "0204122453514331";
		[181] = "015211325"; [190] = "015211325"; [199] = "015211325";
		[240] = "3"; [241] = "2"; [242] = "13"; [244] = "1111";
		[248] = "1"; [249] = "050505"; [255] = "043"; [258] = "04"; [260] = "0333";
		[272] = "0313452421"; [282] = "024340531215";
		[302] = "0232323"; [309] = "0222"; [313] = "0213"; [317] = "0204122453514331";
		[337] = "01235"; [342] = "01235"; [347] = "01235";
		[359] = "01124045443151"; [373] = "01"; [375] = "01124045443151";
		[389] = "015211325"; [398] = "015211325"; [407] = "015211325";
		[422] = "?313452421";
		[437] = "??313452421";
		[453] = "??313452421";
		[469] = "??313452421";
		[485] = "??313452421";
	}
	a.count = 0
	a.show = false
	a.string = ""
	a.string_frame = 0
	a.string_out = ""
	a.time_prev = 0
	a.time_now = 0
	a.canvas = love.graphics.newCanvas(1920, 256)
	if enable_audio then a.music = love.audio.newSource("data/sexim_alive.ogg", "stream") end
	love.graphics.setNewFont("data/noto_serif.ttf", 128)
end


function animate.start()
	a.time_start = love.timer.getTime()
	if enable_audio then a.music:play() end
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if math.floor(a.time_now * 4) > math.floor(a.time_prev * 4) then
		a.count = a.count + 1
		if a.fractions[a.count] then
			a.show = true
			a.string = a.fractions[a.count]
			a.string_frame = 0
		end
		if a.show then
			a.string_frame = a.string_frame + 1
			if a.string_frame > #a.string then
				a.show = false
				a.string_out = ""
			end
		end
		if a.show then
			a.string_out = "." .. a.string:sub(1, a.string_frame)
		end
	end
	a.time_prev = a.time_now
	if a.count == 512 then animate.stop() end
end


function animate.draw()
	love.graphics.setCanvas(a.canvas)
	love.graphics.clear(0, 0, 0, 1)
	if a.show then love.graphics.printf(a.string_out, 0, 0, 1920, "center") end
	love.graphics.setCanvas()
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.draw(a.canvas, 0, 412)
end


function animate.stop()
	playing = false
end


function animate.done()
	a = nil
end


return animate