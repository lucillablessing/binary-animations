local animate = {}


function animate.init()
	a = {}
	a.emph_list = {
		[069] = 1; [070] = 0;
		[235] = 1; [240] = 0;
		[400] = 1; [440] = 0;
		[500] = 1; [540] = 0;
		[666] = 1; [667] = 0;
		[690] = 1; [700] = 0;
		[790] = 1; [800] = 0;
	}
	a.tempo_list = {
		[980] = 360;
		[985] = 320;
		[990] = 280;
		[995] = 240;
	}
	a.count = 0
	a.count_str = "0"
	a.time_prev = 0
	a.time_now = 0
	a.emph = false
	a.tempo = 400
	a.color = {1, 1, 1, 1}
	a.canvas = love.graphics.newCanvas(512, 256)
	if enable_audio then a.music = love.audio.newSource("data/decimal_music.ogg", "stream") end
	love.graphics.setNewFont("data/noto_serif.ttf", 192)
end


function animate.start()
	a.time_start = love.timer.getTime()
	if enable_audio then a.music:play() end
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if math.floor(a.time_now * a.tempo / 60) > math.floor(a.time_prev * a.tempo / 60) then
		a.count = a.count + 1
		a.count_str = tostring(a.count)
		if a.emph_list[a.count] then a.emph = a.emph_list[a.count] == 1 end
		if a.tempo_list[a.count] then
			a.tempo = a.tempo_list[a.count]
			a.time_start = love.timer.getTime()
			a.time_now = 0
			end
		if a.count % 100 == 0 then
			a.color = {1, 0.9, 0.2, 1}
		elseif a.emph then
			a.color = {1, 1, 0.6, 1}
		else
			a.color = {1, 1, 1, 1}
		end
		love.graphics.setColor(a.color)
	end
	a.time_prev = a.time_now
	if a.count == 1000 then animate.stop() end
end


function animate.draw()
	love.graphics.setCanvas(a.canvas)
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.printf(a.count_str, 0, 0, 512, "right")
	love.graphics.setCanvas()
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.draw(a.canvas, 1344, 760)
end


function animate.stop()
	playing = false
end


function animate.done()
	a = nil
end


return animate