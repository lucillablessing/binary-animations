local animate = {}


function animate.init()
	a = {}
	a.binary = {
		 0,  1,  2,  2,  4,  3,  3,  3,  6,  5,
		10,  4, 12,  4,  4,  4,  8,  7, 18,  6,
		 6, 11, 11,  5, 20, 13, 18,  5, 28,  5
	}
	a.binary_red = {
		[3]  = true, [6]  = true, [12] = true, [24] = true,
		[5]  = true, [10] = true, [20] = true,
		[9]  = true, [18] = true,
		[11] = true, [22] = true,
		[13] = true, [26] = true,
		[19] = true,
		[25] = true,
		[27] = true,
		[29] = true
	}
	a.seximal = {
		 0,  1,  1,  2,  1,  1,  2,  3,  2,  2,
		10,  2, 12,  3,  2,  4, 16,  2,  9,  3,
		 3, 11, 11,  3,  5, 13,  3,  4, 14,  2
	}
	a.seximal_red = {
		[11] = true, [22] = true,
		[13] = true, [26] = true,
		[17] = true
	}
	a.time_now = 0
	a.second_state = false
	a.start_height = 384
	a.end_height = 384
	a.canvas = love.graphics.newCanvas(512, 768)
	if enable_audio then a.music = love.audio.newSource("data/divide_and_conquer.ogg", "stream") end
end


function animate.start()
	a.time_start = love.timer.getTime()
	if enable_audio then a.music:play() end
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if a.time_now >= 53.9 then
		a.second_state = true
		a.time_now = 0
		a.time_start = love.timer.getTime()
	end
	if a.second_state then
		if a.time_now >= 36.9 then animate.stop() return end
		local u = a.time_now / 36.9
		a.start_height = 384 - 1008 * u
		a.end_height = 768
	else
		local t = a.time_now / 53.9
		a.start_height = 384
		a.end_height = (1 - t) * 384 + t * 768
	end
end


function animate.draw()
	love.graphics.setCanvas(a.canvas)
	love.graphics.clear(0, 0, 0, 1)
	if playing then
		for i = 2, 30 do
			love.graphics.setColor(a.seximal_red[i] and {1, 0, 0.3, 1} or {1, 1, 1, 1})
			love.graphics.rectangle("fill", 0, a.start_height - 96 + 48 * i, 8 * a.seximal[i], 16)
			love.graphics.setColor(a.binary_red[i] and {1, 0, 0.3, 1} or {1, 1, 1, 1})
			love.graphics.rectangle("fill", 256, a.start_height - 96 + 48 * i, 8 * a.binary[i], 16)
		end
		if not a.second_state then
			love.graphics.setColor(0, 0, 0, 1)
			love.graphics.rectangle("fill", 0, a.end_height, 512, 768 - a.end_height)
		end
	end
	love.graphics.setCanvas()
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.setColor(1, 1, 1, 1)
	love.graphics.draw(a.canvas, 704, 64)
end


function animate.stop()
	playing = false
end


function animate.done()
	a = nil
end


return animate