local animate = {}


function animate.init()
	a = {}
	a.bits = {}
	for i = 0, 8 do a.bits[i] = { ext = false; anim = 0; height = 112; } end
	a.count = 0
	a.time_prev = 0
	a.time_now = 0
	a.canvas = love.graphics.newCanvas(512, 128)
	if enable_audio then a.music = love.audio.newSource("data/binary_counter.ogg", "stream") end
end


function animate.start()
	a.time_start = love.timer.getTime()
	if enable_audio then a.music:play() end
end


function animate.update()
	a.time_now = love.timer.getTime() - a.time_start
	if math.floor(a.time_now * 176 / 60) > math.floor(a.time_prev * 176 / 60) then
		a.count = a.count + 1
		if a.count == 384 then animate.stop() return end
		for i = 0, 8 do
			local b = a.bits[i]
			b.ext = not b.ext
			if b.ext then break end
		end
	end
	if math.floor(a.time_now * 60) > math.floor(a.time_prev * 60) then
		for i = 0, 8 do
			local b = a.bits[i]
			if b.ext and b.anim < 1 then
				b.anim = math.min(1, b.anim + 0.25)
				b.height = (1 - b.anim) * 112
			end
			if not b.ext and b.anim > 0 then
				b.anim = math.max(0, b.anim - 0.25)
				b.height = (1 - b.anim) * 112
			end
		end
	end
	a.time_prev = a.time_now
end


function animate.draw()
	love.graphics.setCanvas(a.canvas)
	love.graphics.clear(0, 0, 0, 1)
	for i = 0, 8 do
		local b = a.bits[i]
		love.graphics.rectangle("fill", 496 - i * 48, b.height, 16, 128 - b.height)
	end
	love.graphics.setCanvas()
	love.graphics.clear(0, 0, 0, 1)
	love.graphics.draw(a.canvas, 1344, 888)
end


function animate.stop()
	playing = false
	a.count = 0
end


function animate.done()
	a = nil
end


return animate